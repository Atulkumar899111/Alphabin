package Configfile;

public class path {

	public static String menu = "//a[@id='nav-hamburger-menu']";
	public static String tvAppliance = "//*[text()='TV, Appliances, Electronics']";
	public static String televisions = "//*[text()='Televisions']";
	public static String samsung = "//*[contains(@class,'a-column a-span12 apb-browse-left-nav')]//*[text()='Samsung']";
	public static String dropdown = "//span[@class='a-dropdown-label']";
	public static String dropDownValue = "//a[text()='Price: High to Low']";
	public static String secondHighest = "//img[@data-image-index='2']";
	public static String text = "//*[text()=' About this item ']";
}
